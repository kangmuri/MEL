package kr.or.mel.mel.admin;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.or.mel.mel.member.book.service.BookServiceImpl;
import kr.or.mel.mel.vo.BookVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequiredArgsConstructor
@RequestMapping("/admin")
public class AdminController {
	
	private final BookServiceImpl bookService;
	
	//관리자 로그인후 페이지(도서관리페이지)
	@GetMapping
	public String adminIndex(Model model) {
		
		List<BookVO> bookList = bookService.bookList();
		log.info("체킁:{}", bookList);
		model.addAttribute("bookList", bookList);
		return "admin/adminBook";
	}
	
	
}
