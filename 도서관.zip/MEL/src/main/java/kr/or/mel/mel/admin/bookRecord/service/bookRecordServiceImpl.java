package kr.or.mel.mel.admin.bookRecord.service;

import java.util.List;

import org.springframework.stereotype.Service;

import kr.or.mel.mel.admin.bookRecord.dao.bookRecordDao;
import kr.or.mel.mel.vo.BookRecordVO;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class bookRecordServiceImpl implements bookRecordService{

	private final bookRecordDao dao;
	
	//도서기록리스트
	@Override
	public List<BookRecordVO> bookRecordList() {

		return dao.bookRecordList();
	}

}
