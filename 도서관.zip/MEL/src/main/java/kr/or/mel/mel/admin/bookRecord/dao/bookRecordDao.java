package kr.or.mel.mel.admin.bookRecord.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import kr.or.mel.mel.vo.BookRecordVO;

@Mapper
public interface bookRecordDao {
	
	//도서기록 리스트
	public List<BookRecordVO> bookRecordList();
}
