package kr.or.mel.mel.vo;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(of = "bookRecordNo")
public class BookRecordVO {

	 private String bookRecordNo;
	 private String startDate;
	 private String endDate;
	 private String rsvtDate;
	 private String returnDate;
	 private String bookClsfCd;
	 private String isbn;
	 private String bookRecordCd;
	 private String userId;
	 
	 private BookVO book;//has a관계 
}
