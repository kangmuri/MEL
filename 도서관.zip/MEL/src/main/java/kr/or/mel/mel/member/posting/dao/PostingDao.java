package kr.or.mel.mel.member.posting.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import kr.or.mel.mel.vo.PostingVO;

@Mapper
public interface PostingDao {
	
	//게시글 리스트 
	public List<PostingVO> postingList();
	
	//게시글 상세조회
	public PostingVO postingDeail(String pstNo);
}
