package kr.or.mel.mel.admin.book.service;

import kr.or.mel.mel.vo.BookVO;

public interface AdminBookService {
	
	//책 등록
	public int bookInsert(BookVO vo);
	
	//책 수정
	public int bookUpdate(BookVO vo);
		
	//책 삭제
	public int bookDelete(String isbn);
}
