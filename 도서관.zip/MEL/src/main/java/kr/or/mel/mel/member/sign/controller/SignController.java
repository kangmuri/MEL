package kr.or.mel.mel.member.sign.controller;

import java.util.Map;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.or.mel.mel.member.sign.service.SignServiceImpl;
import kr.or.mel.mel.vo.UserVO;
import lombok.RequiredArgsConstructor;

@Controller
@Validated
@RequiredArgsConstructor
@RequestMapping("/sign")
public class SignController {

	private final SignServiceImpl service;

	@GetMapping
	public String sign() {
		return "signup";
	}
	
	@PostMapping
	public String signCreate(@Valid UserVO vo,Errors errors, Model model) {
		System.out.println("유효성체크1"+errors.getAllErrors());
		if(errors.hasErrors()) {
			System.out.println("유효성체크2"+errors.getAllErrors());
			model.addAttribute("userData", vo);
			
			Map<String, String> validResult = service.validData(errors);
			for(String key : validResult.keySet()) {
				model.addAttribute(key, validResult.get(key));
			}
			return "signup";
		}else {
			System.out.println("오지말라능");
			service.sign(vo);
			return "login";
		}
	}
}
