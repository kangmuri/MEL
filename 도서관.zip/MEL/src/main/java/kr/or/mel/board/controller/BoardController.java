package kr.or.mel.board.controller;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import kr.or.mel.board.service.BoardServiceImpl;
import kr.or.mel.board.vo.BoardVO;
import kr.or.mel.mel.vo.CmntVO;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Controller
@RequestMapping("/")
public class BoardController {

	private final BoardServiceImpl service;
	
	@GetMapping()
	public String boardList(Model model){
		List<BoardVO> boardList = service.BoardList();
		model.addAttribute("boardList", boardList);
		return "index";
	}
	
	@GetMapping("/{boardCd}")
	public String boardDetail(@PathVariable String boardCd,Model model) {
		BoardVO boardDetail = service.BoardDetail(boardCd);
		List<CmntVO> cmntList = service.CmntList(boardCd);
		model.addAttribute("boardDetail", boardDetail);
		model.addAttribute("cmntList", cmntList);
		return "boardDetail";
	}
	
	@GetMapping("/boardInsert")
	public String boardInsertForm() {
		return "boardInsert";
	}
	
	@ResponseBody
	@PostMapping
	public String boardInsert(@RequestBody BoardVO vo) {
		String result;
		int cnt = service.BoardInsert(vo);
		if(cnt > 0) {
			result = "success";
		}else {
			result = "fail";
		}
		return result;
	}
	
	@ResponseBody
	@PutMapping
	public String boardUpdate(@RequestBody BoardVO vo) {
		String result;
		int cnt = service.BoardUpdate(vo);
		if(cnt > 0) {
			result = "success";
		}else {
			result = "fail";
		}
		return result;
		
	}
	
	@ResponseBody
	@DeleteMapping
	public String boardDelete(@RequestBody Map<String,String> board) {
		
		String result;
		int cnt = service.BoardDelete(board.get("boardCd"));
		if(cnt > 0) {
			result = "success";
		}else {
			result = "fail";
		}
		return result;
	}
	
	//댓글입력
	@ResponseBody
	@PostMapping("/cmntInsert")
	public String cmntInsert(@RequestBody CmntVO vo) {
		String result;
		int cnt = service.CmntInsert(vo);
		if(cnt > 0) {
			result = "success";
		}else {
			result = "fail";
		}
		return result;
	}
}
