package kr.or.mel.mel.admin.bookRecord.service;

import java.util.List;

import kr.or.mel.mel.vo.BookRecordVO;

public interface bookRecordService {

	//도서기록 리스트
	public List<BookRecordVO> bookRecordList();
}
