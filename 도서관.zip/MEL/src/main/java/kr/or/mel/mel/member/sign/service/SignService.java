package kr.or.mel.mel.member.sign.service;

import java.util.Map;

import org.springframework.validation.Errors;

import kr.or.mel.mel.vo.UserVO;

public interface SignService {

	public int sign(UserVO vo);
	
	public Map<String, String> validData(Errors errors);
}
