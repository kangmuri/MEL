package kr.or.mel.mel.member.posting.service;

import java.util.List;

import kr.or.mel.mel.vo.PostingVO;

public interface PostingService {
	
	//게시글 리스트 
	public List<PostingVO> postingList();
	
	//게시글 상세조회
	public PostingVO postingDeail(String pstNo);
}
