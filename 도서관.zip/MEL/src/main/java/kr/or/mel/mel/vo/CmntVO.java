package kr.or.mel.mel.vo;

import lombok.Data;

@Data
public class CmntVO {
	private String cmntNo;
	private String cmntCont;
	private String cmntUserId;
	private String pstNo;
	private String cmntDelYn;
	
}
