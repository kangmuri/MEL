package kr.or.mel.mel.member.sign.dao;

import org.apache.ibatis.annotations.Mapper;

import kr.or.mel.mel.vo.UserVO;

@Mapper
public interface SignDao {

	public int sign(UserVO vo);
}
