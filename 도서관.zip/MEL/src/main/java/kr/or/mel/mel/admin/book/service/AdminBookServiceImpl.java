package kr.or.mel.mel.admin.book.service;

import org.springframework.stereotype.Service;

import kr.or.mel.mel.admin.book.dao.AdminBookDao;
import kr.or.mel.mel.vo.BookVO;
import lombok.RequiredArgsConstructor;

@Service("adminBookService")
@RequiredArgsConstructor
public class AdminBookServiceImpl implements AdminBookService{

	private final AdminBookDao dao;
	
	@Override
	public int bookInsert(BookVO vo) {
		// TODO Auto-generated method stub
		return dao.bookInsert(vo);
	}

	@Override
	public int bookUpdate(BookVO vo) {
		// TODO Auto-generated method stub
		return dao.bookUpdate(vo);
	}

	@Override
	public int bookDelete(String isbn) {
		// TODO Auto-generated method stub
		return dao.bookDelete(isbn);
	}

	
}
