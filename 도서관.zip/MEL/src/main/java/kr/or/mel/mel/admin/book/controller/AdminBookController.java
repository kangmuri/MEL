package kr.or.mel.mel.admin.book.controller;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import kr.or.mel.mel.admin.book.service.AdminBookServiceImpl;
import kr.or.mel.mel.member.book.service.BookServiceImpl;
import kr.or.mel.mel.vo.BookVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
@Slf4j
@Controller
@RequiredArgsConstructor
@RequestMapping("/admin")
public class AdminBookController {

	private final AdminBookServiceImpl service;
	private final BookServiceImpl bookService;

	//도서등록폼
	@GetMapping("/bookInsertForm")
	public String bookInsertForm() {
		return "admin/bookForm";
	}
	
	//도서등록
	@PostMapping("/bookInsert")
	public String bookInsert(@ModelAttribute BookVO vo, @RequestParam("fileName") MultipartFile fileName, Model model) throws IllegalStateException, IOException {
	    String result;
	    String saveDir = "C:/Users/leesk/eclipse-workspace/MEL/src/main/webapp/resources/image/";
	    File directory = new File(saveDir);//저장경로 폴더
	    if (!directory.exists()) {
	        directory.mkdir();
	    }

	    // 이미지 파일이 비어있지 않다면 처리
	    if (!fileName.isEmpty()) {
	        String name = fileName.getOriginalFilename();
	        String uuName = UUID.randomUUID().toString(); // 파일 이름 중복 방지
	        String realName = uuName + "." + name;
	        
	        String fullPath = saveDir + realName;
	        fileName.transferTo(new File(fullPath)); // 저장 경로에 파일 저장
	        vo.setBookImg(realName); // 파일명을 vo에 설정
	    }
	    
	    int cnt = service.bookInsert(vo);
	    if(cnt > 0) {
	    	result = "redirect:/book/"+vo.getIsbn(); 
	    }else {
	    	result = "admin/bookForm";
	    }
	    return result;
	}
	
	//도서수정
	@PostMapping("/bookUpdate")
	@ResponseBody
	public String bookUpdate(@ModelAttribute BookVO vo 
							,@RequestParam(required = false) MultipartFile fileName) throws IllegalStateException, IOException {
		 String result;
		 String saveDir = "C:/Users/leesk/eclipse-workspace/MEL/src/main/webapp/resources/image/";
		    File directory = new File(saveDir);//저장경로 폴더
		    if (!directory.exists()) {
		        directory.mkdir();
		    }

		    // 이미지 파일이 비어있지 않다면 처리
		    if (fileName != null && !fileName.isEmpty()) {
		        String name = fileName.getOriginalFilename();
		        String uuName = UUID.randomUUID().toString(); // 파일 이름 중복 방지
		        String realName = uuName + "." + name;
		        
		        String fullPath = saveDir + realName;
		        fileName.transferTo(new File(fullPath)); // 저장 경로에 파일 저장
		        vo.setBookImg(realName); // 파일명을 vo에 설정
		    }
		    
		    int cnt = service.bookUpdate(vo);
		    
		    if(cnt > 0) {
		    	result = "success";
		    }else {
		    	result = "fail";
		    }
		
		return result;
	}
	
	
	//도서삭제
	@DeleteMapping("/bookDelete")
	@ResponseBody
	public String bookDelete(@RequestBody Map<String, String> book) {
		String result;
		log.info("물이:{}", book);
		int cnt = service.bookDelete(book.get("isbn"));
		if(cnt > 0) {
			result = "success";
		}else {
			result = "fail";
		}
		return result;
	}
}



