package kr.or.mel.board.service;

import java.util.List;

import org.springframework.stereotype.Service;

import kr.or.mel.board.dao.BoardDao;
import kr.or.mel.board.vo.BoardVO;
import kr.or.mel.mel.vo.CmntVO;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class BoardServiceImpl implements BoardService{

	private final BoardDao dao;
	
	@Override
	public List<BoardVO> BoardList() {
		// TODO Auto-generated method stub
		return dao.BoardList();
	}

	@Override
	public BoardVO BoardDetail(String boardCd) {
		// TODO Auto-generated method stub
		return dao.BoardDetail(boardCd);
	}

	@Override
	public int BoardInsert(BoardVO vo) {
		// TODO Auto-generated method stub
		return dao.BoardInsert(vo);
	}

	@Override
	public int BoardUpdate(BoardVO vo) {
		// TODO Auto-generated method stub
		return dao.BoardUpdate(vo);
	}

	@Override
	public int BoardDelete(String boardCd) {
		// TODO Auto-generated method stub
		return dao.BoardDelete(boardCd);
	}
	
	//댓글리스트
	@Override
	public List<CmntVO> CmntList(String boardCd) {
		// TODO Auto-generated method stub
		return dao.CmntList(boardCd);
	}
	
	//댓글등록
	@Override
	public int CmntInsert(CmntVO vo) {
		// TODO Auto-generated method stub
		return dao.CmntInsert(vo);
	}

}
