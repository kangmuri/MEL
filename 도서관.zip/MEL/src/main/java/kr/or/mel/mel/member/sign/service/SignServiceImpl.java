package kr.or.mel.mel.member.sign.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;

import kr.or.mel.mel.member.sign.dao.SignDao;
import kr.or.mel.mel.vo.UserVO;
import lombok.RequiredArgsConstructor;

@Service
@Validated
@RequiredArgsConstructor
public class SignServiceImpl implements SignService{

	private final SignDao dao;
	
	@Override
	public int sign(UserVO vo) {
		// TODO Auto-generated method stub
		return dao.sign(vo);
	}

	@Override
	public Map<String, String> validData(Errors errors) {
		Map<String, String> validResult = new HashMap<>();
		
		for(FieldError error : errors.getFieldErrors()) {
			String validKeyName = error.getField();
			validResult.put(validKeyName, error.getDefaultMessage());
		}
		return validResult;
	}

}
