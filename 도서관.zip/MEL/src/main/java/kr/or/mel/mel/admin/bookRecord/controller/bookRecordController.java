package kr.or.mel.mel.admin.bookRecord.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.or.mel.mel.admin.bookRecord.service.bookRecordServiceImpl;
import kr.or.mel.mel.vo.BookRecordVO;
import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
@RequestMapping("/admin/bookRecord")
public class bookRecordController {

	private final bookRecordServiceImpl service;
	
	@GetMapping
	public String bookRecordList(Model model) {
		List<BookRecordVO> bookRecordList = service.bookRecordList();
		model.addAttribute("bookRecordList", bookRecordList);
		return "admin/bookRecord";
	}
	
}
