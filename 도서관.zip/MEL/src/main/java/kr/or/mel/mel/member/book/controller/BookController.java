package kr.or.mel.mel.member.book.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import kr.or.mel.mel.member.book.service.BookServiceImpl;
import kr.or.mel.mel.vo.BookRecordVO;
import kr.or.mel.mel.vo.BookVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequiredArgsConstructor
@RequestMapping("book")
public class BookController {

	private final BookServiceImpl service;
	//도서 리스트
	@GetMapping
	public String BookList(Model model){
		List<BookVO> bookList = service.bookList();
		model.addAttribute("bookList", bookList);
		return "bookIndex";
	}
	
	//도서상세
	@GetMapping("/{isbn}")
	public String bookDetail(@PathVariable String isbn, Model model) {
		BookVO bookDetail = service.bookDetail(isbn);
		model.addAttribute("bookDetail", bookDetail);
		return "bookDetail";
	}
	
	//도서대여
	@PostMapping("/bookRental")
	@ResponseBody
	public String bookRental(@RequestBody BookRecordVO vo, HttpSession session, Model model) {
		String result = "";
		String userId = (String) session.getAttribute("userId");
		
		vo.setUserId(userId);
		BookVO check =  service.bookDetail(vo.getIsbn()); //도서 잔여수량 체크
		
		List<BookRecordVO> rentCheck = service.bookRentalList(userId);//이미 대여한 도서인지 체크
		for(int i=0; i<rentCheck.size(); i++) {
			if(rentCheck.get(i).getIsbn().equals(vo.getIsbn())) {
				result="rentDupl";
				break;
			}
		}
		
		if(result.equals("rentDupl")) {//이미 대여중일 경우
			result = "rentDupl";
		}else {
			if(check.getPrsntRetentQty() <= 0) {//잔여수량이 없는경우
				result = "zero";
			}else{
				int cnt = service.bookRental(vo);
				if(cnt > 0) {
					result = "success";
				}else {
					result = "fail";
				}
			}
		}
		return result;
	}
	
	//본인이대여한도서리스트
	@GetMapping("/bookRentalList")
	public String bookRentalList(HttpSession session,Model model){
		String userId = (String) session.getAttribute("userId");
		List<BookRecordVO> bookRentalList = service.bookRentalList(userId);
		model.addAttribute("bookRentalList", bookRentalList);
		return "bookRentalList";
	}
	
	//도서반납
	@PostMapping("/bookReturn")
	@ResponseBody
	public String bookReturn(@RequestBody BookRecordVO vo, HttpSession session){
		String result;
		String userId = (String) session.getAttribute("userId");
		vo.setUserId(userId);
		log.info("확인:{}", vo);
		int cnt = service.bookReturn(vo);
		if(cnt > 0) {
			result = "success";
		}else {
			result = "fail";
		}
		return result;
	}
}
