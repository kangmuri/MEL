package kr.or.mel.mel.vo;


import org.apache.logging.log4j.core.config.plugins.validation.constraints.NotBlank;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(of = "userId")
public class UserVO {

	@NotBlank(message="아이디를입력하세요")
	private String userId;
	private String userPw;
	private String userEmail;
	private String userPh;
	private String userImg;
	private String userCd;
	private char delYn;
}
