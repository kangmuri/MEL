package kr.or.mel.mel.member.login.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import kr.or.mel.mel.member.book.service.BookServiceImpl;
import kr.or.mel.mel.member.login.service.MemberLoginServiceImpl;
import kr.or.mel.mel.vo.BookVO;
import kr.or.mel.mel.vo.UserVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequiredArgsConstructor
@RequestMapping("/login")
public class MemberLoginController {
	
	private final MemberLoginServiceImpl service;
	private final BookServiceImpl bookService;
	
	//로그인 페이지 이동
	@GetMapping
	public String login() {
		return "login";
	}
	
	//로그인
	@PostMapping()
	public String loginCheck(@RequestParam String userId, @RequestParam String userPw, HttpSession session,
			Model model) {
		String result;
		UserVO vo = new UserVO();
		vo.setUserId(userId);
		vo.setUserPw(userPw);
		UserVO Check = service.selectUserCheck(vo);//아이디와 비밀번호 맞는지 체크
		if(Check == null) {
			model.addAttribute("loginError", "아이디와 비밀번호가 일치하지않습니다.");
			result = "login";
		}else {
			if(Check.getUserCd().equals("MEMBER")) {//회원이 로그인할 경우 페이지
				model.addAttribute("Check",Check);
				session.setAttribute("userId", vo.getUserId());
				session.setAttribute("userCd", Check.getUserCd());
				result = "redirect:/book";
			}else {//관리자가 로그인할 경우 페이지
				model.addAttribute("Check",Check);
				session.setAttribute("userId", vo.getUserId());
				session.setAttribute("userCd", Check.getUserCd());
				result = "redirect:/admin";
			}
			
		}
		return result;
	}
	
	//로그아웃
	@GetMapping("/logout")
	public String logOut(HttpSession session, Model model) {
		System.out.printf("세션확인",session);
		log.info("세션{}", session);
		session.invalidate();//세션 없애기
		List<BookVO> bookList = bookService.bookList();
		model.addAttribute("bookList", bookList);
		return "bookIndex";
	}
}
