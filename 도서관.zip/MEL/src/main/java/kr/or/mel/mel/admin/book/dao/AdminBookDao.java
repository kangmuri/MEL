package kr.or.mel.mel.admin.book.dao;

import org.apache.ibatis.annotations.Mapper;

import kr.or.mel.mel.vo.BookVO;
import lombok.Data;

@Mapper
public interface AdminBookDao {
	
	//책 등록
	public int bookInsert(BookVO vo);
	
	//책 수정
	public int bookUpdate(BookVO vo);
	
	//책 삭제
	public int bookDelete(String isbn);
}
