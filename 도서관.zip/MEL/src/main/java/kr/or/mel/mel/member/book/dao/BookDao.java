package kr.or.mel.mel.member.book.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import kr.or.mel.mel.vo.BookRecordVO;
import kr.or.mel.mel.vo.BookVO;

@Mapper
public interface BookDao {

	//책리스트
	public List<BookVO> bookList();
	
	//책디테일
	public BookVO bookDetail(String isbn);
	
	//도서대여
	public int bookRental(BookRecordVO vo);
	
	//도서반납
	public int bookReturn(BookRecordVO vo);
	
	//현재 대여중인 도서리스트
	public List<BookRecordVO> bookRentalList(String userId);
	
	//도서대여시 잔여권수 감소
	public int qtyAdd(String isbn);
	
	//도서반납시 잔여권수 추가
	public int qtyMinus(String isbn);
}
