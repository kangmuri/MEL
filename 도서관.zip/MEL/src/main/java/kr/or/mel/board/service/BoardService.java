package kr.or.mel.board.service;

import java.util.List;

import kr.or.mel.board.vo.BoardVO;
import kr.or.mel.mel.vo.CmntVO;

public interface BoardService {

	
public List<BoardVO> BoardList();
	
	public BoardVO BoardDetail(String boardCd);
	
	public int BoardInsert(BoardVO vo);
	
	public int BoardUpdate(BoardVO vo);
	
	public int BoardDelete(String boardCd);
	
	//댓글리스트
	public List<CmntVO> CmntList(String boardCd);
	
	//댓글등록
	public int CmntInsert(CmntVO vo);
}
