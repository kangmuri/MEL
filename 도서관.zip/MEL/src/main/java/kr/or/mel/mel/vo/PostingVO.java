package kr.or.mel.mel.vo;

import lombok.Data;

@Data
public class PostingVO {

	 private String pstNo;
	 private String pstTtl;
	 private String pstCont;
	 private int pstRdcnt;
	 private String attachImg;
	 private String pstUserId;
	 private String boardCd;
	 private String pstWrtDt;
	 private String pstDelYn;
	 private String pstUdtDt;
	 private String pstDelDt;
	 private String pstOthbcDt;
}
