package kr.or.mel.mel.member.login.service;

import org.springframework.stereotype.Service;

import kr.or.mel.mel.member.login.dao.MemberLoginDao;
import kr.or.mel.mel.vo.UserVO;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class MemberLoginServiceImpl implements MemberLoginService{

	private final MemberLoginDao dao;

	@Override
	public UserVO selectUserCheck(UserVO vo) {
		// TODO Auto-generated method stub
		return dao.selectUserCheck(vo);
	}
	

}
