package kr.or.mel.mel.vo;


import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(of = "isbn")
public class BookVO {

	 private String isbn;
	 private String bookNm;
	 private String bookCont;
	 private String bookImg;
	 private String author;
	 private int page;
	 private String publicDate;
	 private Integer retentQty;
	 private int prsntRetentQty;
	 private String bookClsfCd;
	 private String delYn;
}
