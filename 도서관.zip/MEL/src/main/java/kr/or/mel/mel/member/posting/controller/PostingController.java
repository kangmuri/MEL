package kr.or.mel.mel.member.posting.controller;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.or.mel.mel.member.posting.service.PostingServiceImpl;
import kr.or.mel.mel.vo.PostingVO;
import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
@RequestMapping("/posting")
public class PostingController {

	private final PostingServiceImpl service;
	
	@GetMapping
	public String postingList(Model model) {
		List<PostingVO> postingList = service.postingList();
		model.addAttribute("postingList", postingList);
		return "posting";
	}
	
	@GetMapping("/{pstNo}")
	public String postingDetail(@PathVariable String pstNo, Model model) {
		PostingVO postingDetail = service.postingDeail(pstNo);
		model.addAttribute("postingDetail", postingDetail);
	return "postingDetail";
	}
}
