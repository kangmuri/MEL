package kr.or.mel.mel.member.login.service;

import kr.or.mel.mel.vo.UserVO;

public interface MemberLoginService {

	public UserVO selectUserCheck(UserVO vo);
}
