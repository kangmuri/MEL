package kr.or.mel.mel.member.posting.service;

import java.util.List;

import org.springframework.stereotype.Service;

import kr.or.mel.mel.member.posting.dao.PostingDao;
import kr.or.mel.mel.vo.PostingVO;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class PostingServiceImpl implements PostingService{

	private final PostingDao dao;
	
	@Override
	public List<PostingVO> postingList() {
		// TODO Auto-generated method stub
		return dao.postingList();
	}

	@Override
	public PostingVO postingDeail(String pstNo) {
		// TODO Auto-generated method stub
		return dao.postingDeail(pstNo);
	}

}
