package kr.or.mel.mel.member.book.service;

import java.util.List;

import kr.or.mel.mel.vo.BookRecordVO;
import kr.or.mel.mel.vo.BookVO;

public interface BookService {
	
	//책리스트
	public List<BookVO> bookList();
	
	//책디테일
	public BookVO bookDetail(String isbn);
	
	//도서대여
	public int bookRental(BookRecordVO vo);
	
	//도서반납
	public int bookReturn(BookRecordVO vo);
	
	//현재 대여중인 도서리스트
	public List<BookRecordVO> bookRentalList(String userId);
}
