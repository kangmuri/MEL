package kr.or.mel.mel.member.login.dao;

import org.apache.ibatis.annotations.Mapper;

import kr.or.mel.mel.vo.UserVO;

@Mapper
public interface MemberLoginDao {

	public UserVO selectUserCheck(UserVO vo);
	
}
