package kr.or.mel.board.vo;

import lombok.Data;

@Data
public class BoardVO {

	private String boardCd;
	private String boardNm;
	private String filePath;
	private String fileNm;
	
}
