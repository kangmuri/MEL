package kr.or.mel.mel.member.book.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import kr.or.mel.mel.member.book.dao.BookDao;
import kr.or.mel.mel.vo.BookRecordVO;
import kr.or.mel.mel.vo.BookVO;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class BookServiceImpl implements BookService{
	
	private final BookDao dao;
	//도서리스트
	@Override
	public List<BookVO> bookList() {
		// TODO Auto-generated method stub
		return dao.bookList();
	}

	//도서상세
	@Override
	public BookVO bookDetail(String isbn) {
		// TODO Auto-generated method stub
		return dao.bookDetail(isbn);
	}

	//도서대여
	@Override
	public int bookRental(BookRecordVO vo) {
			
		dao.qtyMinus(vo.getIsbn());//잔여도서 감소
		return dao.bookRental(vo);
	}

	//도서반납
	@Override
	public int bookReturn(BookRecordVO vo) {
		dao.qtyAdd(vo.getIsbn());//잔여도서 증가
		return dao.bookReturn(vo);
	}

	//현재 대여중인 도서리스트
	@Override
	public List<BookRecordVO> bookRentalList(String userId) {
		// TODO Auto-generated method stub
		return dao.bookRentalList(userId);
	}
	
	


}
